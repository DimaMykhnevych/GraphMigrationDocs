﻿namespace GraphMigrator;

internal interface IApplicationRunner
{
    void Run();
}

