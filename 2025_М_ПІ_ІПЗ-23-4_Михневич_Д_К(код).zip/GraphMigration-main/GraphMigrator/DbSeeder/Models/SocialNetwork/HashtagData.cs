﻿namespace DbSeeder.Models.SocialNetwork;

public class HashtagData
{
    public Guid HashtagId { get; set; }
    public string Name { get; set; }
}
