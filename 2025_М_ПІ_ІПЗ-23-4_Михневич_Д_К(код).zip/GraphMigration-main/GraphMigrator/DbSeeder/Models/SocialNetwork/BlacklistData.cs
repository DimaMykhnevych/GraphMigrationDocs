﻿namespace DbSeeder.Models.SocialNetwork;

public class BlacklistData
{
    public Guid BlackListId { get; set; }
    public string Reason { get; set; }
}
