﻿namespace DbSeeder.Models.SocialNetwork;

public class HobbyData
{
    public Guid HobbyId { get; set; }
    public string Name { get; set; }
}
