﻿namespace DbSeeder.Models.SocialNetwork;

public class SkillData
{
    public Guid SkillId { get; set; }
    public string Name { get; set; }
    public string Category { get; set; }
}

