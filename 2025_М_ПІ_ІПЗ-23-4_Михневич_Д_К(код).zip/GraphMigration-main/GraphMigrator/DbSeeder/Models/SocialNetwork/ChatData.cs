﻿namespace DbSeeder.Models.SocialNetwork;

public class ChatData
{
    public Guid ChatId { get; set; }
    public string Title { get; set; }
    public DateTime CreationDate { get; set; }
}

