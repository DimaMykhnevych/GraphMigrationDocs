﻿namespace DbSeeder.Models.Game;

public class DroppedItemData
{
    public int Id { get; set; }
    public int ItemId { get; set; }
    public int LootId { get; set; }
    public int Quantity { get; set; }
}