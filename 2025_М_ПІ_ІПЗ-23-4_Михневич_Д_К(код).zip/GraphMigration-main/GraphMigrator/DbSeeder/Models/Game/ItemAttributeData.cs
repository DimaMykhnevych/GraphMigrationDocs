﻿namespace DbSeeder.Models.Game;

public class ItemAttributeData
{
    public int Id { get; set; }
    public int Value { get; set; }
    public int ItemId { get; set; }
    public int AttributeId { get; set; }
}
