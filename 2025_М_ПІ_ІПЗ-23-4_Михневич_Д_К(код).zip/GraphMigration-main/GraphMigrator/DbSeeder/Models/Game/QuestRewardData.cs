﻿namespace DbSeeder.Models.Game;

public class QuestRewardData
{
    public int Id { get; set; }
    public int QuestId { get; set; }
    public int ItemId { get; set; }
    public int Count { get; set; }
}