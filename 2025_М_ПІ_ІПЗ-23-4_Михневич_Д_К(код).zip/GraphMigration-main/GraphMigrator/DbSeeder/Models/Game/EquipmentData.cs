﻿namespace DbSeeder.Models.Game;

public class EquipmentData
{
    public int Id { get; set; }
    public int CharacterId { get; set; }
    public int ItemId { get; set; }
    public string Slot { get; set; }
}
