﻿namespace DbSeeder.Models.Game;

public class VictoryRewardData
{
    public int Id { get; set; }
    public int Count { get; set; }
    public int ItemId { get; set; }
    public int EnemyId { get; set; }
}