﻿namespace DbSeeder.Models.Game;

public class EnemyAttributeData
{
    public int Id { get; set; }
    public int Value { get; set; }
    public int EnemyId { get; set; }
    public int AttributeId { get; set; }
}
