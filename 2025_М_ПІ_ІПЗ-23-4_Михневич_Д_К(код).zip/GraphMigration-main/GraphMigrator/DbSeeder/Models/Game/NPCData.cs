﻿namespace DbSeeder.Models.Game;

public class NPCData
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Coordinates { get; set; }
}
