﻿namespace GraphMigrator.Algorithms.Rel2Graph;

public interface IRel2GraphAlgorithm
{
    Task MigrateToGraphDatabaseAsync();
}

