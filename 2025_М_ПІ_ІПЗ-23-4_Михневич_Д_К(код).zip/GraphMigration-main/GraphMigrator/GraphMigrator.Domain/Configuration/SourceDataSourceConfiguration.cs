﻿namespace GraphMigrator.Domain.Configuration;

public class SourceDataSourceConfiguration
{
    public string ConnectionString { get; set; }
}

