﻿namespace GraphMigrator.Domain.Configuration;

public class TargetDatbaseNames
{
    public string Rel2Graph { get; set; }
    public string Rel2GraphParallel { get; set; }
    public string Improved { get; set; }
}
