﻿namespace GraphMigrator.Domain.Configuration;

public class ImprovedAlgorithmSettings
{
    public int DataColumnsAmountWithComplexPrimaryKey { get; set; } = 3;
}
