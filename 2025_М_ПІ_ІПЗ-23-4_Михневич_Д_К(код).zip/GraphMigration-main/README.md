# GraphMigration
The methods of transforming structured data into a graph model
