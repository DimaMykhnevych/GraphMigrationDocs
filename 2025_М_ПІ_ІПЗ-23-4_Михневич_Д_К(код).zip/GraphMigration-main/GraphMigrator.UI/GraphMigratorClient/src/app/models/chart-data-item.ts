export interface ChartDataItem {
  name: string;
  value: number;
}
