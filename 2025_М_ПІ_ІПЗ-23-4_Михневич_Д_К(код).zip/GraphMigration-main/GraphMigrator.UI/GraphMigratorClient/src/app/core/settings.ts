export class AppSettings {
  // http://localhost:5218/api
  // https://localhost:7027/api
  public static apiHost = 'https://localhost:7027/api';
}
